package com.example.healthpoint_final;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AppointmentPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_page);
    }
}