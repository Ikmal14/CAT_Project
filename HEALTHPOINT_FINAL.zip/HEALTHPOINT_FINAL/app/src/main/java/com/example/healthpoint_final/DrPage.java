package com.example.healthpoint_final;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DrPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dr_page);
    }
}